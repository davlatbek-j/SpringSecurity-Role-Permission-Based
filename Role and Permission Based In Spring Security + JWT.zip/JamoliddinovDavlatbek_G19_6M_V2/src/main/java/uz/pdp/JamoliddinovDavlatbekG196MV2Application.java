package uz.pdp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JamoliddinovDavlatbekG196MV2Application {

    public static void main(String[] args) {
        SpringApplication.run(JamoliddinovDavlatbekG196MV2Application.class, args);
    }

}
