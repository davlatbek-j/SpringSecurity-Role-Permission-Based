package uz.pdp.component;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import uz.pdp.entity.Permission;
import uz.pdp.entity.Role;
import uz.pdp.entity.User;
import uz.pdp.entity.enums.PermissionName;
import uz.pdp.entity.enums.RoleName;
import uz.pdp.service.PermissionService;
import uz.pdp.service.RoleService;
import uz.pdp.service.UserService;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@Component
@RequiredArgsConstructor
public class DataRunner implements CommandLineRunner {

    private  final UserService userService ;
    private final RoleService roleService;
    private final PermissionService permissionService;
    private  final PasswordEncoder encoder ;

    @Override
    public void run(String... args) throws Exception {

        for (RoleName value : RoleName.values()) {
//            roleService.save(  new Role( value ) );
        }


        for (PermissionName value : PermissionName.values()) {
//            permissionService.save(  new Permission( value ) );
        }

        User admin1 = new User();
        admin1.setUsername("admin1");
        admin1.setPassword(encoder.encode("admin1"));
        admin1.setRoles(new HashSet<>(Collections.singleton(roleService.findByRoleName(RoleName.ROLE_ADMIN))));
        admin1.setPermissions(new HashSet<>(Collections.singleton(permissionService.findByPermissionName(PermissionName.ADD_PRODUCT))));


        User admin2 = new User();
        admin2.setUsername("admin2");
        admin2.setPassword(encoder.encode("admin2"));
        admin2.setRoles(new HashSet<>(Collections.singleton(roleService.findByRoleName(RoleName.ROLE_ADMIN))));
        admin2.setPermissions(new HashSet<>(Collections.singleton(permissionService.findByPermissionName(PermissionName.ALL_PERMISSION))));


        User superAdmin = new User();
        superAdmin.setUsername("super");
        superAdmin.setPassword(encoder.encode("super"));
        superAdmin.setRoles(new HashSet<>(Collections.singleton(roleService.findByRoleName(RoleName.ROLE_SUPER_ADMIN))));
        superAdmin.setPermissions(new HashSet<>(Collections.singleton(permissionService.findByPermissionName(PermissionName.ALL_PERMISSION ))));


        User user3 = new User();
        user3.setUsername("client");
        user3.setPassword(encoder.encode("client"));
        user3.setRoles(new HashSet<>(Collections.singleton(roleService.findByRoleName(RoleName.ROLE_CLIENT))));
        user3.setPermissions(new HashSet<>(Collections.singleton(permissionService.findByPermissionName(PermissionName.ADD_PRODUCT))));



//        userService.save(superAdmin);
//        userService.save(admin1);
//        userService.save(admin2);
//        userService.save(user3);


    }


}
