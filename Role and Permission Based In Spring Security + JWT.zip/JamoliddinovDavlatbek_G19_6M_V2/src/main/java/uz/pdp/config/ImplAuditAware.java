package uz.pdp.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import uz.pdp.entity.User;

import java.util.Optional;

@Configuration
@EnableJpaAuditing
public class ImplAuditAware implements AuditorAware<Integer> {
    @Override
    public Optional<Integer> getCurrentAuditor() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        System.err.println("AuditAWare Runned  authentication:" +authentication );

        if (authentication==null || !authentication.isAuthenticated() ) {
            System.err.println("AuditAWare getCurrentAuditor ->  authentication==null");
            return Optional.empty();
        }


        System.err.println("AuditAWare getCurrentAuditor -> " +  ((User) authentication.getPrincipal()).getId() );
        return Optional.of(  ((User) authentication.getPrincipal()).getId() ) ;
    }

}
