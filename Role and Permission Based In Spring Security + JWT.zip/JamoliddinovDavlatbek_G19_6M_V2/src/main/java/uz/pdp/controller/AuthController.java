package uz.pdp.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.pdp.payload.SignIn;
import uz.pdp.service.AuthService;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private  final AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody SignIn signIn){
        return  authService.login(signIn);
    }

}
