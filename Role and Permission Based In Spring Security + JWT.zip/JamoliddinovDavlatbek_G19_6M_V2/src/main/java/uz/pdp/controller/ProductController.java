package uz.pdp.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import uz.pdp.payload.ProductDto;
import uz.pdp.service.ProductService;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/product")
public class ProductController {
    private  final ProductService productService ;

    @PostMapping
    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN','CREATE_PRODUCT','ROLE_SUPER_ADMIN')")   /// Ishladi....
    public ResponseEntity<?> save(@RequestBody ProductDto productDto){
        return productService.save(productDto);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN','DELETE_PRODUCT', 'ROLE_SUPER_ADMIN')" )
    public  ResponseEntity<?> deleteById( @PathVariable Integer id ){
        return productService.delete(id) ;
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_CLIENT','ROLE_SUPER_ADMIN')")  // admin ham client ham get qila oladi
    public  ResponseEntity<?> getById(@PathVariable Integer id ){
        return productService.getById(id);
    }

    @PutMapping("/edit/{id}")
    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN','UPDATE_BOOK','ROLE_SUPER_ADMIN' )")
    public HttpEntity<?> editParam(@PathVariable Integer id, @RequestBody ProductDto productDto) {
        return productService.editProduct(id, productDto);

    }
    @GetMapping("/all")
//    @PreAuthorize("hasPermission('GET_ALL')")
    public ResponseEntity<?> getAllProduct(){
        return  productService.getAll();
    }

}
