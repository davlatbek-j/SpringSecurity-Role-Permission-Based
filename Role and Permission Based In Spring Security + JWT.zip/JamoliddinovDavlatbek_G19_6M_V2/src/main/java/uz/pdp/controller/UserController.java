package uz.pdp.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import uz.pdp.entity.Permission;
import uz.pdp.entity.Role;
import uz.pdp.entity.enums.RoleName;
import uz.pdp.payload.UserDto;
import uz.pdp.service.UserService;


@RestController
@RequiredArgsConstructor
@RequestMapping("/api/user")
public class UserController {
    private  final UserService userService ;


    @PostMapping("/addRole/{id}")   // shu id lik userga role set qilish
    @PreAuthorize("hasAnyRole('ROLE_SUPER_ADMIN')")
    public ResponseEntity<?> addAdmin(@PathVariable Integer id , @RequestBody Role role ){

        System.err.println(role);

        return userService.addAdmin(id, role);
    }

    @PostMapping("/addPermission/{id}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN')")
    public  ResponseEntity<?> addPermission(@PathVariable Integer id , @RequestBody Permission permission){
      return    userService.addPermission( id,  permission );
    }
}
