package uz.pdp.entity.enums;

public enum PermissionName {

    ALL_PERMISSION,
    CREATE_PRODUCT,
    ADD_PRODUCT,
    GET_PRODUCT,
    READ_PRODUCT,
    UPDATE_PRODUCT,
    DELETE_PRODUCT
}
