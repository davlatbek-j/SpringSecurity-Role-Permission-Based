package uz.pdp.entity.enums;

public enum RoleName {

    ROLE_SUPER_ADMIN,   // admin va user CRUD qila oladi
    ROLE_ADMIN,
    ROLE_CLIENT
}
