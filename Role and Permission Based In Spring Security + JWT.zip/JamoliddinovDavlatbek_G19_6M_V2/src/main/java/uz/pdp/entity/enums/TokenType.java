package uz.pdp.entity.enums;

public enum TokenType {
    BEARER
}
