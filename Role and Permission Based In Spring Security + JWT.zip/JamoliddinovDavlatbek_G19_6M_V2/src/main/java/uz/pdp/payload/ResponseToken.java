package uz.pdp.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import uz.pdp.entity.enums.TokenType;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseToken {
    private TokenType tokenType=TokenType.BEARER;
    private String token ;

    public ResponseToken(String token) {
        this.token = token;
    }

}
