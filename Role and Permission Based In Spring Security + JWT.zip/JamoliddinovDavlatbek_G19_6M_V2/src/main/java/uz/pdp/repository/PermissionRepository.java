package uz.pdp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.pdp.entity.Permission;
import uz.pdp.entity.enums.PermissionName;
import uz.pdp.service.PermissionService;

public interface PermissionRepository extends JpaRepository<Permission ,Integer> {

    Permission findByPermissionName(PermissionName permissionName);

}
