package uz.pdp.security;

import io.jsonwebtoken.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import uz.pdp.entity.User;
import uz.pdp.service.UserService;

import java.util.Date;

@Component
@RequiredArgsConstructor
public class JwtTokenProvider {

    @Value("${jwt.token.secretKey}")
    private  String secretKey;

    @Value("${jwt.token.expireDateInMilliSeconds}")
    private  Long expirationDate;


    private  final UserService userService ;

    public  String generateTokenFromId(Integer id ){
        Date now= new Date() ;
        String token =
                Jwts
                        .builder()
                        .setSubject( id.toString() )
                        .setIssuedAt( now )
                        .setExpiration( new Date( now.getTime() + expirationDate )  )
                        .signWith(SignatureAlgorithm.HS512,secretKey)
                        .compact();
        System.err.println("generate Token From Id :" + token ); // Qizilda ajrab turishi uchun
        return  token ;
    }

    public boolean validateToken(String token){
        try {
            Jwts
                    .parser()
                    .setSigningKey(secretKey)
                    .parseClaimsJws(token);
            System.err.println("validate token  returm -> true ");  // belgilab qoyish , ajrab turishi uchun
            return  true ;
        } catch (ExpiredJwtException e) {
            System.err.println("Muddati o'tgan token");
        } catch (UnsupportedJwtException e) {
            System.err.println("Token emas ");
        } catch (MalformedJwtException e) {
            System.err.println("Buzilgan token ");
        } catch (SignatureException e) {
            System.err.println("Kalit so'z xato ");
        } catch (IllegalArgumentException e) {
            System.err.println("Bosh token ");
        }
        System.err.println("validate token return -> false ");
        return  false ;
    }

    public User getUserFromToken(String token ){

        if (validateToken(token)) {
            String subject =
                    Jwts
                            .parser()
                            .setSigningKey(secretKey)
                            .parseClaimsJws(token)
                            .getBody()
                            .getSubject();
            System.err.println("Get User From token ->" + userService.findById( Integer.valueOf(subject) ));
            return  userService.findById( Integer.valueOf(subject) ) ;
        }
        return null;
    }


}
