package uz.pdp.service;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import uz.pdp.entity.User;
import uz.pdp.payload.ResponseToken;
import uz.pdp.payload.SignIn;
import uz.pdp.repository.UserRepository;
import uz.pdp.security.JwtFilter;
import uz.pdp.security.JwtTokenProvider;

@Service
@RequiredArgsConstructor
public class AuthService {

    private  final UserService userService  ;

    private  final JwtTokenProvider jwtTokenProvider ;
    private  final PasswordEncoder passwordEncoder;


    public ResponseEntity<?> login(SignIn signIn) {
        User userFromDb= userService.findByUsername(signIn.getUsername());

        if (userFromDb.isActive()
                && passwordEncoder.matches(signIn.getPassword(), userFromDb.getPassword())  ){
            String token= jwtTokenProvider.generateTokenFromId(userFromDb.getId() );
            ResponseToken responseToken= new ResponseToken( token );
            return  ResponseEntity.ok().body(responseToken) ;
        }
        return  ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not Found with username : " + signIn.getUsername() );
    }

}
