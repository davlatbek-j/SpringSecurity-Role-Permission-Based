package uz.pdp.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uz.pdp.entity.Permission;
import uz.pdp.entity.enums.PermissionName;
import uz.pdp.repository.PermissionRepository;

@Service
@RequiredArgsConstructor
public class PermissionService {
    private  final PermissionRepository permissionRepository ;

    public Permission findByPermissionName(PermissionName permissionName){
        return permissionRepository.findByPermissionName(permissionName);
    }

    public void save(Permission permission) {
        permissionRepository.save(permission);
    }

}
