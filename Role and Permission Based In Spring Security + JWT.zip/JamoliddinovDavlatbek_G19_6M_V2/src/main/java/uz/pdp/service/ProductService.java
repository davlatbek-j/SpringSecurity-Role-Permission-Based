package uz.pdp.service;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import uz.pdp.entity.Product;
import uz.pdp.payload.ProductDto;
import uz.pdp.repository.ProductRepository;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ProductService {
    private  final ProductRepository productRepository ;

    public ResponseEntity<?> save(ProductDto productDto ){
        Product product= new Product(
                productDto.getName(),
                productDto.getPrice(),
                productDto.isActive()
        );

        Product save = productRepository.save(product);

        return ResponseEntity.ok().body( "Saved : " + save) ;

    }

    public ResponseEntity<?> delete(Integer id ){
        try {
            productRepository.deleteById(id);
            return  ResponseEntity.ok().body("Product deleted id : " +id );
        } catch (Exception e) {
            return  ResponseEntity.status(HttpStatus.BAD_REQUEST).body("not deleted : " + id ) ;
        }

    }

    public  ResponseEntity<?> editProduct(ProductDto productDto){
        Optional<Product> productFromDB = productRepository.findById(productDto.getId());

        if (productFromDB.isPresent() ){
            Product product = productFromDB.get() ;
            product.setName(productDto.getName() );
            product.setPrice(productDto.getPrice() );
            product.setActive(productDto.isActive());
            Product save = productRepository.save(product);
            return  ResponseEntity.status(201).body("edited product : " + save) ;
        }

        return  ResponseEntity.status(HttpStatus.NOT_FOUND).body("Product not found ") ;
    }


    public ResponseEntity<?> getById(Integer id) {
        Optional<Product> byId = productRepository.findById(id);

        if (byId.isPresent() ){
            return  ResponseEntity.ok().body( byId.get() );
        }
        return  ResponseEntity.status(HttpStatus.NOT_FOUND).body("Product not found !! id :" + id ) ;

    }

    public ResponseEntity<?> editProduct(Integer id, ProductDto productDto) {
        Optional<Product> byId = productRepository.findById(id);

        if (byId.isPresent()) {
            Product productFromDB = byId.get();
            productFromDB.setName(productDto.getName());
            productFromDB.setPrice(productDto.getPrice());
            productFromDB.setActive(productDto.isActive());
            Product save = productRepository.save(productFromDB);
            return  ResponseEntity.ok().body("Updated to : " + save) ;
        }

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Something wrong !!! ") ;
    }

    public ResponseEntity<?> getAll() {
        try {
            List<Product> all = productRepository.findAll();
            return  ResponseEntity.ok().body(all);
        } catch (Exception ignored) {

        }
        return  ResponseEntity.status(HttpStatus.NOT_FOUND).body("Something wrong ....");
    }

}
