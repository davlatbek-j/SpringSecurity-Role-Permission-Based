package uz.pdp.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uz.pdp.entity.Role;
import uz.pdp.entity.enums.RoleName;
import uz.pdp.repository.RoleRepository;

@Service
@RequiredArgsConstructor
public class RoleService {
    private  final RoleRepository roleRepository ;


    public Role findByRoleName(RoleName roleName){
        Role byRoleName = roleRepository.findByRoleName(roleName);

        if (byRoleName!=null){
            return  byRoleName;
        }
        System.err.println("Role not found RoleName :" + roleName.name() );
        return  null ;
    }

    public Role save(Role role){
        return roleRepository.save(role);
    }

}
