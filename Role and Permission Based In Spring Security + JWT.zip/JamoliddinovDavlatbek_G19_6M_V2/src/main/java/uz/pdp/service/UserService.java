package uz.pdp.service;

import lombok.RequiredArgsConstructor;
import org.hibernate.mapping.Collection;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import uz.pdp.entity.Permission;
import uz.pdp.entity.Role;
import uz.pdp.entity.User;
import uz.pdp.entity.enums.RoleName;
import uz.pdp.repository.UserRepository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.Collections;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class UserService implements UserDetailsService {
    private  final UserRepository userRepository ;


    public User findById( Integer id ){
        Optional<User> byId = userRepository.findById(id);

        if (byId.isPresent() ){
            return  byId.get() ;
        }
        System.err.println("\nUser not Found  id : " + id); //QIZILDA AJRAB TURISHI UCHUN serr
        return null;
    }

    public  User findByUsername(String username){
        User byUsername = userRepository.findByUsername(username);
        if (byUsername!=null){
            return  byUsername ;
        }
        System.err.println("User not Found username : " + username);
        return  null ;
    }


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return userRepository.findByUsername(username);
    }

    public User save(User user) {
        return  userRepository.save(user);
    }

    public ResponseEntity<?> deleteById(Integer id){
        try {
        userRepository.deleteById(id);
        return  ResponseEntity.ok().body("User deleted id :" + id ) ;
        } catch (Exception e) {
            System.err.println("User not Deleted  id :" + id );
        }
        return  ResponseEntity.status(HttpStatus.NOT_FOUND).body("User NOT  deleted !!! id :" + id ) ;
    }

    public ResponseEntity<?> addAdmin(Integer id, Role role) {
        Optional<User> byId = userRepository.findById(id);

        if (byId.isPresent()) {
            User user = byId.get();
            Set<Role> newRoles = user.getRoles();
            newRoles.add(role);
            user.setRoles( newRoles );
            User save = userRepository.save(user);
            return  ResponseEntity.ok().body( "User upgraded to Admin : " + save  ) ;
        }
        return  ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Something wrong !!!! ");
    }

    public ResponseEntity<?> addPermission(Integer id, Permission permission) {
        Optional<User> byId = userRepository.findById(id);

        if (byId.isPresent()) {

            User userFromDb = byId.get();

            Set<Permission> newPermissions = userFromDb.getPermissions();

            newPermissions.add(permission);

            userFromDb.setPermissions(newPermissions);

            User saved = userRepository.save(userFromDb);

            return  ResponseEntity.ok().body( "Add permission to user : " + saved );
        }
        return  ResponseEntity.status(HttpStatus.BAD_REQUEST).body( "Something Wrong , Contact with admin !!! "  );

    }

}
